<?php
	require('connect.php');
	if(!isset($_SESSION)) {
		session_start();
	}
	if (isset($_POST['studentid'])) 
	{
		$db = connect_db();
		$studentid = mysqli_real_escape_string($db,$_POST['studentid']);
		$course = $_POST['course'];
	
		$sql = "SELECT CourseId FROM Course WHERE CourseName = '$course';";
		$result = mysqli_query($db, $sql);
		if ($result->num_rows == 1)
		{
			$courseid = $result->fetch_assoc();
			$courseid = $courseid["CourseId"];
		
			$sql = "INSERT INTO Enrollment (CourseID, StudentID) VALUES ($courseid, $studentid);";
			$result = mysqli_query($db, $sql);
		}
	}
	mysqli_close($db);
	header("location: addApp.php");
?>