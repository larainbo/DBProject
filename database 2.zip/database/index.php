<?php
	require('connect.php');
	if(!isset($_SESSION)) {
		session_start();
	}
	$table = "Users";
	
	$db = connect_db();
	// Check if user is logged in
	if (isset($_SESSION['username'])) 
	{
		$sql = "SELECT UserID FROM $table WHERE Username = '" . $_SESSION['username'] . "';";
		$result = mysqli_query($db, $sql);
		if ($result->num_rows == 1)
		{
			$uid = $result->fetch_assoc();
			$uid = $uid["UserID"];
			$logged = true;
		}
		else 
		{
			
			$logged = false;
		}		
	}
	else
	{
		$logged = true;
	}
?>


<DOCTYPE HTML>
<html>
<head>
<style>

body {margin:0;}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #8e1318;
  color: black;
}

.topnav a.active {
    background-color: #4CAF50;
    color: white;
    }
    
.center {
    margin: auto;
    width: 40%;
    background: #8e1318;
    padding: 10px;
    text-align: center;
    border-radius: 15px 50px;
   
}

.button {
    background-color: #000000; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
     -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    border-radius: 50%;
}
.button:hover {
    background-color: #c67007;
    color: white;
}
}
</style>
<?php
if ($logged == true) {
	echo '
	
		<!-- NAVBAR -->
	<nav class ="topnav">
		<div>
		<a class ="topnav" href="index.php">DBMS Project</a>
		
		</div>
	</nav>
</head>

<body style="background-image:url(fire.png); background-size:cover; background-repeat:no-repeat; background-position:center center">
	<div class = "center">
		<br>
		<div >
			<form  action="addStudent.php">
				<input class = "button" type="submit" value="Add a Student">
			</form>
			<form action="addCourse.php">
				<input class = "button" type="submit" value="Add a Course">
			</form>
			<form  action="addApp.php">
				<input class = "button" type="submit" value="Add an Application">
			</form>
			<form action="viewStudents.php">
				<input class = "button" type="submit" value="View All Students">
			</form>
			<form  action="viewbyDept.php">
				<input class = "button" type="submit" value="View All Courses by department">
			</form>
			<form  action="viewbyStudent.php">
				<input class = "button" type="submit" value="View All Courses by Student">
			</form>
	';
}
else {
	echo '
<head>
	<nav class ="topnav">
		<div>
		<a  href="index.php">DBMS Project</a>
		<a  href="login1.php" style="float: right">Login</a>
		</div>
	</nav>
</head
<body style="background-image:url(fire.png); background-size:cover; background-repeat:no-repeat; background-position:center center">
	<div>
		<br>
		<div>
			<form style = "text-align: center" action="addStudent.php">
				<input  type="submit" value="Add a Student">
			</form>
			<form action="addApp.php">
				<input type="submit" value="Add an Application">
			</form>
			<form action="viewStudents.php">
				<input  type="submit" value="View All Students">
			</form>
			<form action="viewbyDept.php">
				<input  type="submit"  value="View All Courses">
			</form>
	';
}
?>
		</div>
	</div>
</body>
</html>