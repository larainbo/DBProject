<?php
	require('connect.php');
	if (!isset($_SESSION)) {
		session_start();
	}
	$db = connect_db();
	$studentid = $_POST[studentid];
	$table = "Users";
	if (isset($_SESSION['username'])) 
	{
		$sql = "SELECT UserID FROM $table WHERE Username = '" . $_SESSION['username'] . "';";
		$result = mysqli_query($db, $sql);
		if ($result->num_rows == 1)
		{
			$uid = $result->fetch_assoc();
			$uid = $uid["UserID"];
			$logged = true;
		}
		else 
		{
			$logged = false;
		}		
	}
	else
	{
		$logged = false;
	}
?>
<DOCTYPE HTML>
<html>
<style>

body {margin:0;}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #8e1318;
  color: black;
}

.topnav a.active {
    background-color: #4CAF50;
    color: white;
}

.center {
    margin: auto;
    width: 40%;
    background: #8e1318;
    padding: 10px;
    text-align: center;
    border-radius: 15px 50px;
   
}

.button {
    background-color: #000000; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
     -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    border-radius: 50%;
}
.button:hover {
    background-color: #c67007;
    color: white;
}
</style>

	<?php
	if ($logged == true) {
	echo '
	<!-- NAVBAR -->
	<nav class ="topnav" >
		<div >
		<a  href="index.php">DBMS Project</a>
		</div>
	</nav>
	';
	}
	else {
	echo '	
	
	<!-- NAVBAR -->
	<nav class ="topnav">
		<div >
		<a  href="index.php">DBMS Project</a>
		</div>
	</nav>
	';
	}
	?>

<body style="background-image:url(fire.png); background-size:cover; background-repeat:no-repeat; background-position:center center">
	<div class = "center">
		
		<div ><table class="table">
			<thead>
				<tr ><th>Course ID</th><th>Course Name</th><th>Department Name</th>
			</thead>
			<tbody>
				<?php
				
				
				$sql = " select Course.CourseId as 'Course ID', Course.CourseName AS 'Course Name', Course.DepartmentName AS 'Department Name', Enrollment.StudentID AS 'Student ID'  from Course, Enrollment WHERE StudentId = $studentid AND Course.CourseId = Enrollment.CourseID;";
				$result = mysqli_query($db,$sql);
				if ($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {
						$courseid = $row['Course ID'];
						$coursename = $row['Course Name'];
						$departmentname = $row['Department Name'];
						$StudentID = $row['Student ID'];
						
				?>
				<tr class="info">
					<td><?=$courseid?></td>
					<td><?=$coursename?></td>
					<td><?=$departmentname?></td>
					<td><?=$StudentID?></td>
					
				</tr>
				<?php
					}
				}
				mysqli_close($db);
				?>
			</tbody>
		</table></div>
			<div><a  href="index.php">Go Back</a></div>
	</div>
</body>
</html>