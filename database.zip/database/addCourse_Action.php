<?php
	require('connect.php');
	if(!isset($_SESSION)) {
		session_start();
	}
	if (isset($_POST['coursename'])) 
	{
		$db = connect_db();
		$coursename = $_POST['coursename'];
		$departmentname = mysqli_real_escape_string($db,$_POST['departmentname']);
	
		$sql = "INSERT INTO Course (CourseName, DepartmentName) VALUES ('$coursename', '$departmentname');";
		$result = mysqli_query($db, $sql);
	}
	mysqli_close($db);
	header("location: addCourse.php");
?>