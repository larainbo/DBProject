<?php
	require('connect.php');
	if (!isset($_SESSION)) {
		session_start();
	}
	$db = connect_db();
	$table = "Users";
	
	if (isset($_SESSION['username'])) 
	{
		$sql = "SELECT UserID FROM $table WHERE Username = '" . $_SESSION['username'] . "';";
		$result = mysqli_query($db, $sql);
		if ($result->num_rows == 1)
		{
			$uid = $result->fetch_assoc();
			$uid = $uid["UserID"];
			$logged = true;
		}
		else 
		{
			$logged = false;
		}		
	}
	else
	{
		$logged = false;
	}
?>
<DOCTYPE HTML>
<html>
<head>
	
	<?php
	if ($logged == true) {
	echo '
	<!-- NAVBAR -->
	<nav>
		<div>
		<a  href="index.php">DBMS Project</a>
		</div>
	</nav>
	';
	}
	else {
	echo '	
	
	<!-- NAVBAR -->
	<nav >
		<div>
		<a  href="index.php">DBMS Project</a>
		<a  href="login1.php" style="float: right">Login</a>
		</div>
	</nav>
	';
	}
	?>
</head>

<body >
	<div >
		<h2>Please Enter the ID of the Student you want to search for</h2>
	<form method="post" action="viewbyStudent_Action.php">
			<div>
			<label>Student ID</label>
			<input type="text" name="studentid" id="studentid">
			</div>
			</div>
			<button type="submit">Search!</button>
			or
			<a href="index.php">Go Back</a>
		</form>
	</div>
</body>
</html>