<?php
	require('controller.php');
	if(!isset($_SESSION)) {
		session_start();
	}

	if (isset($_POST['studentid'])) 
	{
		$db = connect_db();
		$studentid = $_POST['studentid'];
		$jobid = $_POST['jobid'];
	
		$sql = "INSERT INTO Applications VALUES ($studentid, $jobid);";
		$result = mysqli_query($db, $sql);
	}
	mysqli_close($db);
	header("location: addApp.php");
?>
