<?php
	require('controller.php');
	if(!isset($_SESSION)) {
		session_start();
	}

	if (isset($_POST['jobid'])) 
	{
		$db = connect_db();
		$jobid = $_POST['jobid'];
		$companyname = mysqli_real_escape_string($db,$_POST['companyname']);
		$jobtitle = mysqli_real_escape_string($db,$_POST['jobtitle']);
		$salary = $_POST['salary'];
	
		$sql = "INSERT INTO Jobs VALUES ($jobid, '$companyname', '$jobtitle', $salary);";
		$result = mysqli_query($db, $sql);
	}
	mysqli_close($db);
	header("location: addJob.php");
?>
