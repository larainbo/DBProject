<?php
	function connect_db ()
	{
		$username = "dtvanbus";
		$password = "iVo7KaiY";
		$dbname = "dtvanbus";
		$servername = "localhost";

		$connection = new mysqli ($servername, $username, $password, $dbname);
		if ($connection->connect_error)
			die("Connection failed: " . $connection->connect_error);
		else
			return $connection;
	}
?>
