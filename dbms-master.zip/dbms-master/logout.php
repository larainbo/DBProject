<?php
	//require('controller.php');
	if(!isset($_SESSION)) {
		session_start();
	}
	
	if(isset($_SESSION)) {
		unset($_SESSION['username']);
		session_unset();
		header("location: index.php");
	}
?>
